export default function PageNotFound() {
  return <h1 className="mt-lg-5 text-center">Page not found</h1>;
}
