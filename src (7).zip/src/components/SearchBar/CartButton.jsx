import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { selectUser } from '../../redux/userSlice';
import { Typography, Button, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';

const CartButton = () => {
  const user = useSelector(selectUser);
  const cartItems = user && user.cartItems ? user.cartItems : []; // Добавляем проверку на существование user и user.cartItems

  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      <Button onClick={handleOpen}>
        Корзина ({cartItems.length})
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Корзина</DialogTitle>
        <DialogContent>
          {cartItems.length ? ( // Добавляем проверку на существование cartItems перед обращением к его свойствам
            cartItems.map(item => (
              <div key={item.productId}>
                <Typography>{item.product.title}</Typography>
                <Typography>{item.product.price} $</Typography>
                <Typography>Количество: {item.quantity}</Typography>
              </div>
            ))
          ) : (
            <Typography>Корзина пуста</Typography>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Закрыть</Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default CartButton;
