import * as React from 'react';
import ListSubheader from '@mui/material/ListSubheader';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Collapse from '@mui/material/Collapse';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import StarBorder from '@mui/icons-material/StarBorder';
import GridViewIcon from '@mui/icons-material/GridView';
import SmartphoneIcon from '@mui/icons-material/Smartphone';
import LaptopIcon from '@mui/icons-material/Laptop';
import BlenderIcon from '@mui/icons-material/Blender';
import LiveTvIcon from '@mui/icons-material/LiveTv';
import WatchIcon from '@mui/icons-material/Watch';
import SportsEsportsIcon from '@mui/icons-material/SportsEsports';
import RoofingIcon from '@mui/icons-material/Roofing';
import SpeakerIcon from '@mui/icons-material/Speaker';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import HealthAndSafetyIcon from '@mui/icons-material/HealthAndSafety';
import CountertopsIcon from '@mui/icons-material/Countertops';

export default function Catalog() {
  const [open, setOpen] = React.useState(true); // Устанавливаем начальное значение в true

  const handleClick = () => {
    setOpen(!open);
  };

  return (
    <List
      sx={{ width: '100%', maxWidth: 360 }}
      component="nav"
      aria-labelledby="nested-list-subheader"
      subheader={
        <ListSubheader component="div" id="nested-list-subheader">
          <ListItemButton
            variant="contained"
            onClick={handleClick}
            sx={{height: 65, bgcolor: 'success.main', color: 'white', '&:hover': {
                bgcolor: 'success.main !important' }}}>
            <ListItemIcon>
              <GridViewIcon color="white" />
            </ListItemIcon>
            <ListItemText primary="Catalogue" />
            {open ? <ExpandLess /> : <ExpandMore />}
          </ListItemButton>
        </ListSubheader>
      }
    >
      <Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <SmartphoneIcon />
            </ListItemIcon>
            <ListItemText primary="Smartphones" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <LaptopIcon />
            </ListItemIcon>
            <ListItemText primary="Laptops" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <BlenderIcon />
            </ListItemIcon>
            <ListItemText primary="For the kitchen" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <LiveTvIcon />
            </ListItemIcon>
            <ListItemText primary="TV" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <WatchIcon />
            </ListItemIcon>
            <ListItemText primary="Gadgets" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <SportsEsportsIcon />
            </ListItemIcon>
            <ListItemText primary="Consoles and Gaming" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <RoofingIcon />
            </ListItemIcon>
            <ListItemText primary="For Home" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <SpeakerIcon />
            </ListItemIcon>
            <ListItemText primary="Audio" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <PhotoCameraIcon />
            </ListItemIcon>
            <ListItemText primary="Photo" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <HealthAndSafetyIcon />
            </ListItemIcon>
            <ListItemText primary="Health & Care" />
          </ListItemButton>

          <ListItemButton sx={{ pl: 4 }}>
            <ListItemIcon>
              <CountertopsIcon />
            </ListItemIcon>
            <ListItemText primary="Dishes" />
          </ListItemButton>
        </List>
      </Collapse>
    </List>
  );
}
