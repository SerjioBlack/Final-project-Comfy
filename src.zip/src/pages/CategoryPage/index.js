import CategoryPage from "./CategoryPage";
export default CategoryPage;
