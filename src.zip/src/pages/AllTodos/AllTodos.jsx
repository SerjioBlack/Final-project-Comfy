import React from 'react';
import BaseTemplate from "../../templates/BaseTemplate";

const AllTodos = () => {
    return (
        <BaseTemplate title='All Todos'>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum, repellat?
        </BaseTemplate>
    );
};

export default AllTodos;
