import BaseTemplate from "./BaseTemplate";
export default BaseTemplate;
